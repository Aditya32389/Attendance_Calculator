An Android app which calculates your attendance. 
It calculates the number of classes required to complete 75% attendance, also calculates the number days you can bunk while still maintaining 75% attendance.
It shows Mr Incredible transforming to uncanny meme faces based on your attendance.
You can download and use the app by downloading it from the release section.
